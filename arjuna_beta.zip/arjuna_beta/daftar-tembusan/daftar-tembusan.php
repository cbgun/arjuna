<?php
$judul = ucwords(strtolower(str_replace("-", " ", $getnameurl)));
?>

<style>
    .buttonTambah {
        box-shadow: inset 0px 1px 0px 0px #35bcfd;
        background: linear-gradient(to bottom, #2294fe 5%, #2280fe 100%);
        background-color: #2294fe;
        border-radius: 6px;
        border: 1px solid #25a8fe;

        cursor: pointer;
        color: #ffffff;
        font-family: Arial;
        font-size: 13px;
        font-weight: bold;
        padding: 6px 24px;
        text-decoration: none;
        text-shadow: 0px 1px 0px #2280fe;
        text-align: center;
    }

    .buttonTambah:hover {
        background: linear-gradient(to bottom, #2280fe 5%, #2280fe 100%);
        background-color: #2280fe;
    }

    .buttonTambah:active {
        position: relative;
        top: 1px;
    }

    .buttonSinkron {
        box-shadow: inset 0px 1px 0px 0px #a9e977;
        background: linear-gradient(to bottom, #87d87a 5%, #87d87a 100%);
        background-color: #87d87a;
        border-radius: 6px;
        border: 1px solid #87d87a;
        display: inline-block;

        cursor: pointer;
        color: #ffffff;
        font-family: Arial;
        font-size: 13px;
        font-weight: bold;
        padding: 6px 24px;
        text-decoration: none;
        text-shadow: 0px 1px 0px #87d87a;
    }

    .buttonSinkron:hover {
        background: linear-gradient(to bottom, #87d87a 5%, #a9e977 100%);
        background-color: #87d87a;
    }

    .buttonSinkron:active {
        position: relative;
        top: 1px;
    }
</style>

<div class="card shadow mb-4" style="overflow:auto">
    <div class="card-header py-3" style="background-color: #f6f0f0;">
        <h6 class="m-0 font-weight-bold text-primary" style="color:#2C3930!important"><?= $judul; ?></h6>
    </div>
    <div class="card-body">
    <div style="display: flex; flex-direction: column; align-items: end;">
            <button style="margin:5px;" class="btn btn-success buttonTambah" onclick="tambahData();"><i class="fa fa-plus"></i> TAMBAH</button>
            <button style="margin:5px;" class="btn btn-success buttonSinkron" onclick="sinkron();"><i class="fa fa-sync"></i> SINKRONISASI TEMBUSAN</button>
        </div>
        <div class="col-12 mb-3" style="font-size:15px;">
            <label>Pada saat menambahkan <b>Tembusan Baru</b> terdapat beberapa perbedaan antara lain:</label>
            <ul style="margin-top: 10px;">
                <li><b>Tembusan Internal SRIKANDI</b> adalah Daftar Tembusan berdasarkan Instansi dan Unit Kerja / Satuan Kerja Anda</li>
                <li><b>Tembusan Eksternal SRIKANDI</b> adalah Daftar Tembusan berdasarkan keseluruhan Instansi dan Unit Kerja / Satuan Kerja</li>
                <li><b>Tembusan Eksternal Non SRIKANDI</b> adalah Daftar Tembusan berdasarkan diluar lingkup SRIKANDI</li>
            </ul>
        </div>
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>JENIS TEMBUSAN</th>
                        <th>KEPADA</th>
                        <th>AKSI</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>
    </div>
</div>