<!-- Sidebar -->
<style>
    .icon-custom {
        font-family: "Font Awesome 6 Free";
        font-size: 24px;
        content: "\f4e5";
    }

    .sidebar .nav-item .nav-link[data-toggle=collapse].collapsed::after {
        color: #BDB395;
    }

    .iconarsip {
        padding: 8px;
        border-radius: 5px;
        color: #BDB395;
        background: linear-gradient(to bottom, #60c0d0 5%, #26858e 100%);
        background-color: #60c0d0;
    }

    span,
    a {
        color: #504B38;
    }

    .bg-gradient-primary {
        background: #F6F0F0;
        border-right: 1px dashed #BDB395;
    }

    .collapse-inner {
        border: 1px dashed rgba(24, 49, 83);
    }

    .sidebar-heading {  
        color: #B3C8CF !important;
    }

    .table th {
        font-size: 12px;
    }
</style>

<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
        <div class="sidebar-brand-text mx-3">
            <img src="<?= $linkurl; ?>img/logo_rs.png" style="width:100%">
        </div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Nav Item - Dashboard -->
    <li class="nav-item active">
        <a class="nav-link" href="index.html">
            <i class="fa-brands fa-windows iconarsip"></i>
            <span>Beranda</span>
        </a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading -->
    <div class="sidebar-heading">PENCIPTAAN ARSIP</div>

    <!-- Nav Item - Naskah Masuk -->
    <li class="nav-item active">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
            aria-expanded="true" aria-controls="collapseTwo">
            <i class="fa-solid fa-inbox iconarsip"></i>
            <span>Naskah Masuk</span>
        </a>
        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Naskah Masuk</h6>
                <a class="collapse-item" href="<?= $linkurl; ?>daftar-naskah-masuk">Daftar Naskah Masuk</a>
                <a class="collapse-item" href="<?= $linkurl; ?>daftar-naskah-tembusan">Tembusan</a>
                <a class="collapse-item" href="<?= $linkurl; ?>daftar-naskah-disposisi">Disposisi</a>
                <a class="collapse-item" href="<?= $linkurl; ?>daftar-naskah-koordinasi">Koordinasi</a>
                <a class="collapse-item" href="<?= $linkurl; ?>daftar-naskah-arahan">Arahan</a>
                <a class="collapse-item" href="<?= $linkurl; ?>daftar-Log-Naskah-Disposisi">Log Disposisi</a>
                <a class="collapse-item" href="<?= $linkurl; ?>daftar-Log-Naskah-Koordinasi">Log Koordinasi</a>
                <a class="collapse-item" href="<?= $linkurl; ?>daftar-Log-Naskah-Arahan">Log Arahan</a>
            </div>
        </div>
    </li>

    <!-- Nav Item - Naskah Keluar -->
    <li class="nav-item active">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseNaskahkeluar"
            aria-expanded="true" aria-controls="collapseNaskahkeluar">
            <i class="fa-solid fa-envelope-open-text iconarsip"></i>
            <span>Naskah Keluar</span>
        </a>
        <div id="collapseNaskahkeluar" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Naskah Keluar</h6>
                <a class="collapse-item" href="<?= $linkurl; ?>registrasi-naskah-keluar">Registrasi Naskah Keluar</a>
                <a class="collapse-item" href="<?= $linkurl; ?>daftar-naskah-keluar">Daftar Naskah Keluar</a>
                <a class="collapse-item" href="<?= $linkurl; ?>log-naskah-keluar">Log Naskah Keluar</a>
                <a class="collapse-item" href="<?= $linkurl; ?>verifikasi-naskah">Verifikasi Naskah</a>
                <a class="collapse-item" href="<?= $linkurl; ?>tandatangan-naskah">Tandatangan Naskah</a>
            </div>
        </div>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading -->
    <div class="sidebar-heading">MASTER</div>

    <!-- Nav Item - Pengguna -->
    <li class="nav-item active">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages"
            aria-expanded="true" aria-controls="collapsePages">
            <i class="fa-solid fa-users iconarsip"></i>
            <span>Pengguna</span>
        </a>
        <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Pengguna</h6>
                <a class="collapse-item" href="<?= $linkurl; ?>daftar-penandatangan">Penandatangan</a>
                <a class="collapse-item" href="<?= $linkurl; ?>daftar-tujuan-naskah">Tujuan Naskah</a>
                <a class="collapse-item" href="<?= $linkurl; ?>daftar-grup-tujuan-naskah">Grup Tujuan Naskah</a>
                <a class="collapse-item" href="<?= $linkurl; ?>daftar-verifikator">Verifikator</a>
                <a class="collapse-item" href="<?= $linkurl; ?>daftar-tembusan">Tembusan</a>
                <a class="collapse-item" href="<?= $linkurl; ?>daftar-grup-tembusan">Grup Tembusan</a>
                <a class="collapse-item" href="<?= $linkurl; ?>daftar-grup-tujuan-disposisi">Grup Tujuan Disposisi</a>
            </div>
        </div>
    </li>

    <!-- Heading -->
    <div class="sidebar-heading">Instrument Kearsipan</div>

    <!-- Nav Item - Tata Naskah Dinas -->
    <li class="nav-item active">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseinstrument"
            aria-expanded="true" aria-controls="collapseinstrument">
            <i class="fa-solid fa-file-archive iconarsip"></i>
            <span>Tata Naskah Dinas</span>
        </a>
        <div id="collapseinstrument" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Tata Naskah Dinas</h6>
                <a class="collapse-item" href="<?= $linkurl; ?>daftar-template-naskah">Template Naskah</a>
                <a class="collapse-item" href="<?= $linkurl; ?>intruksi-disposisi">Instruksi Disposisi</a>
            </div>
        </div>
    </li>

        <!-- Heading -->
        <div class="sidebar-heading">Pemeliharaan Arsip</div>

</ul>
<!-- End of Sidebar -->