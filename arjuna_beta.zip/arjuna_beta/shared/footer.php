<!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>
                            &copy; 2025 ISIRS <a href="https://rsup-drsitanala.go.id/" target="_blank">|| RSUP Dr. Sitanala</a>.  All rights reserved.
                             <!-- Copyright &copy; rsdr.sitanala 2025 -->
                        </span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->