<?php 
	$judul=ucwords(strtolower(str_replace("-"," ",$getnameurl)));
?>                    
					<div class="card shadow mb-4" style="overflow:auto">
                        <div class="card-header py-3" style="background-color: #f6f0f0;">
                            <h6 class="m-0 font-weight-bold text-primary" style="color:#2C3930!important" ><?=$judul;?></h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive" >
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>NO</th>
                                            <th>TANGGAL ARAHAN</th>
                                            <th>TANGGAL NASKAH MASUK</th>
                                            <th>URAIAN INFORMASI</th>
                                            <th>INSTRUKSI</th>
                                            <th>STATUS TIDAK LANJUT</th>
                                            <th>STATUS BACA</th>
                                            <th>AKSI</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <tr class="border-b border-slate-300">
                                            <td></td>
                                            <td class="max-w-[20rem] py-6 px-2">
                                                <div class="flex justify-start items-center">
                                                    <div class="MuiInputBase-root MuiInputBase-colorPrimary css-e5c77h">
                                                        <input placeholder="Cari Tanggal Naskah" class="MuiInputBase-input css-1bqqmdo rounded-md border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"" type="date">
                                                    </div>
                                                </div>
                                            </td>
                                            <td class="max-w-[20rem] py-6 px-2">
                                                <div class="flex justify-start items-center">
                                                    <div class="MuiInputBase-root MuiInputBase-colorPrimary css-e5c77h">
                                                        <input placeholder="Cari Tanggal Naskah" class="MuiInputBase-input css-1bqqmdo rounded-md border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"" type="date">
                                                    </div>
                                                </div>
                                            </td>
                                            <td class="max-w-[20rem] py-6 px-2">
                                                <div class="flex justify-start items-center">
                                                <input placeholder="Cari Uraian Informasi" class="MuiInputBase-input css-1bqqmdo rounded-md border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"" type="text" fdprocessedid="3oblb"> 
                                                </div>
                                            </td>
                                            <td class="max-w-[20rem] py-6 px-2">
                                                <div class="flex justify-start items-center">
                                                    <div class="MuiInputBase-root MuiInputBase-colorPrimary css-e5c77h">
                                                    <input placeholder="Cari Intruksi" class="MuiInputBase-input css-1bqqmdo rounded-md border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"" type="text" fdprocessedid="xljhyh"> 
                                                    </div>
                                                </div>
                                            </td>
                                            <td class="max-w-[20rem] py-6 px-2">
                                                <div class="css-1jqq78o-placeholder" id="react-select-2-placeholder"> Cari Status Tindak Lanjut
                                                <select class="w-full p-2 border rounded">
                                                    <option value="sudah">Sudah</option>
                                                    <option value="belum">Belum</option>
                                                </select>
                                                </div>
                                            </td> 
                                            <td class="max-w-[20rem] py-6 px-2">
                                                <div class="css-1jqq78o-placeholder" id="react-select-2-placeholder"> Cari Status Baca
                                                <select class="w-full p-2 border rounded">
                                                    <option value="sudah">Sudah</option>
                                                    <option value="belum">Belum</option>
                                                </select>
                                                </div>
                                            </td>
                                            <td></td>           
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
