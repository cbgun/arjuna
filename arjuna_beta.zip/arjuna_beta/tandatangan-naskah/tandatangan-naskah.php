<?php
$judul = ucwords(strtolower(str_replace("-", " ", $getnameurl)));
?>

<style>
    .myButton {
        box-shadow: inset 0px 1px 0px 0px #35bcfd;
        background: linear-gradient(to bottom, #2294fe 5%, #2280fe 100%);
        background-color: #2294fe;
        border-radius: 6px;
        border: 1px solid #25a8fe;

        cursor: pointer;
        color: #ffffff;
        font-family: Arial;
        font-size: 13px;
        font-weight: bold;
        padding: 6px 24px;
        text-decoration: none;
        text-shadow: 0px 1px 0px #2280fe;
        text-align: center;
    }

    .myButton:hover {
        background: linear-gradient(to bottom, #2280fe 5%, #2280fe 100%);
        background-color: #2280fe;
    }

    .myButton:active {
        position: relative;
        top: 1px;
    }
</style>

<div class="card shadow mb-4" style="overflow:auto">
    <div class="card-header py-3" style="background-color: #f6f0f0;">
        <h6 class="m-0 font-weight-bold text-primary" style="color:#2C3930!important"><?= $judul; ?></h6>
    </div>
    <div class="card-body">
        <div style="display: flex; flex-direction: column; align-items: end;">
            <button style="margin:5px;" class="btn btn-success myButton" onclick="tambahData();"><i class="fas fa-signature"></i> TANDATANGANI BANYAK NASKAH</button>
        </div>
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>NO</th>
                        <th>TANGGAL NASKAH</th>
                        <th>NOMOR NASKAH</th>
                        <th>HAL</th>
                        <th>ASAL NASKAH</th>
                        <th>STATUS PENANDATANGANAN</th>
                        <th>KIRIM STATUS</th>
                        <th>AKSI</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>
    </div>
</div>