<div>
    <div class="text-center">
        <h3>Selamat datang di Aplikasi</h3>
        <img src="img/logo_rs.png" style="width:40%;">
        <h6 class="text-center">Arsip Rumah Sakit Jaringan Untuk Naskah Administrasi</h6>
    </div>
    <div class="text-center">
        <h3>RSUP. Dr. Sitanala</h3>
    </div>
    <div class="d-flex justify-content-end mt-4" style="gap: 10px;">
        <a href="<?= $linkurl; ?>statistik" class="btn btn-primary px-4">Tampilkan Statistik</a>
    </div>
</div>