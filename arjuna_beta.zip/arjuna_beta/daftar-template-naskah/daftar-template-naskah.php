<?php
$judul = ucwords(strtolower(str_replace("-", " ", $getnameurl)));
?>
<style>
	.stripe {
		font-size: 12px !important;
	}
	#example td{
		color:#000;
		font-size:1em;
	}
	#example thead th{
		color:#000;
		font-size:1em;
	}
	
	
	#iconrs{
		font-size:1.3em;
	}
</style>
<div class="card shadow mb-4" style="overflow:auto">
	<div class="card-header py-3" style="background-color: #f6f0f0;">
		<h6 class="m-0 font-weight-bold text-primary" style="color:#2C3930!important"><?= $judul; ?></h6>
	</div>
	<div class="card-body">
		<div class="table-responsive">
			<table id="example" class="stripe row-border order-column" style="width:100%">
				<thead>
					<tr>
						<th style="text-align:center; width:25px;">JENIS NASKAH</th>
						<th>UKURAN</th>
						<th>NAMA FILE</th>
						<th>FILE</th>
						<th style="text-align:center; width:1px;">AKSI</th>
					</tr>
				</thead>
				<tfoot>
					<tr>
						<th style="text-align:center; width:25px;">JENIS NASKAH</th>
						<th>UKURAN</th>
						<th>NAMA FILE</th>
						<th>FILE</th>
						<th style="text-align:center; width:1px;">AKSI</th>
					</tr>
				</tfoot>
				<tbody>
					<?php
					for ($i = 1; $i <= 5; $i++) {
						echo '<tr style="padding:20px;">
												<td style="width:25px; padding:25px">Dinas Luar</td>
												<td>0 KB</td>
												<td>Surat</td>
												<td style="text-align:center; width:1px;"><i class="fa fa-file-word" id="iconrs" id="iconrs" style="font-size:1.7em"></i></td>
												<td style="text-align:center; width:1px;"><i class="fa fa-eye" id="iconrs" style="font-size:1em"></i></td>
											</tr>';
					}
					?>
				</tbody>
			</table>
		</div>
	</div>
</div>