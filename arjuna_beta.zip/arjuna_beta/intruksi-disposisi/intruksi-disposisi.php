<?php
$judul = ucwords(strtolower(str_replace("-", " ", $getnameurl)));
include "../config/config_db.php";
?>

<style>
	.stripe {
		font-size: 12px !important;
	}
	.myButton {
	box-shadow:inset 0px 1px 0px 0px #cf866c;
	background:linear-gradient(to bottom, #d0451b 5%, #bc3315 100%);
	background-color:#d0451b;
	border-radius:3px;
	border:1px solid #942911;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:12px;
	padding:6px 24px;
	text-decoration:none;
	text-shadow:0px 1px 0px #854629;
}
.myButton:hover {
	background:linear-gradient(to bottom, #bc3315 5%, #d0451b 100%);
	background-color:#bc3315;
}
.myButton:active {
	position:relative;
	top:1px;
}
.myButtona {
	box-shadow:inset 0px 1px 0px 0px #d9fbbe;
	background:linear-gradient(to bottom, #b8e356 5%, #a5cc52 100%);
	background-color:#b8e356;
	border-radius:6px;
	border:1px solid #83c41a;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:Arial;
	font-size:12px;
	font-weight:bold;
	padding:3px 21px;
	text-decoration:none;
	text-shadow:0px 1px 0px #86ae47;
}
.myButtona:hover {
	background:linear-gradient(to bottom, #a5cc52 5%, #b8e356 100%);
	background-color:#a5cc52;
}
.myButtona:active {
	position:relative;
	top:1px;
}
</style>

<div class="card shadow mb-4" style="overflow:auto">
	<div class="card-header py-3" style="background-color: #f6f0f0;">
		<h6 class="m-0 font-weight-bold text-primary" style="color:#2C3930!important"><?= $judul; ?></h6>
	</div>
	<div class="card-body">
		<div class="table-responsive">
			<table id="example" class="stripe row-border order-column" style="width:100%">
				<thead>
					<tr>
						<th style="text-align:left; width:25px;">INTRUKSI DISPOSISI</th>
						<th style="text-align:left; width:25px;">STATUS</th>
						<th style="text-align:center; width:1px;">AKSI</th>
					</tr>
				</thead>
				<tbody>
					<?php
					$tsqlmenu = "SELECT * from m_instruksi_disposisi order by nminstruksi asc";
					$qmenu = $dbh->query($tsqlmenu);
					$qmenu->execute();
					$no = 1;
					while ($row = $qmenu->fetch()) {
						if($row['status']=="Aktif"){
							$button='<div class="btn myButtona">'.strtoupper(strtolower($row['status'])).'</div>';
						}else{
							$button='<div class="btn myButton">'.strtoupper(strtolower($row['status'])).'</div>';
						}
						echo '<tr>
                            <td style="width:60%;padding:15px;" nowrap>' . strtoupper(strtolower($row['nminstruksi'])) . '</td>
                            <td style="width:60%" nowrap>' .$button. '</td>
							<td style="text-align:center; width:1px;"><i class="fa fa-eye" id="iconrs"></i></td>
                        </tr>';
					}
					?>
				</tbody>
			</table>
		</div>
	</div>
</div>