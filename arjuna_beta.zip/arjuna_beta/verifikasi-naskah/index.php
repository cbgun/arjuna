<?php
	include"../index.php";
?>