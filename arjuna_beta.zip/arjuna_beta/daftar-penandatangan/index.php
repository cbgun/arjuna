<?php
	include "../index.php";
?>

<script>
	$(document).ready(function () {
		$('#example thead th').each( function () {
        var title = $(this).text();
		if(title=='#'){
				$(this).append( '<br><input type="checkbox" style="width:100%; padding:5px; border-radius:5px; border :0.5px solid #580e4a" type="text" placeholder='+title+' />' );
			
		}else{
				$(this).append( '<br><input style="width:100%; padding:5px; border-radius:5px; border :0.5px solid #580e4a" type="text" placeholder='+title+' />' );
		}
    } );
 
    // DataTable
    var table = $('#example').DataTable({
      scrollX: true,
	  searching: false
    });
 
    // Apply the search
    table.columns().every( function () {
        var that = this;
        $( 'input', this.header() ).on( 'keyup change', function () {
            if ( that.search() !== this.value ) {
                that
                    .search( this.value )
                    .draw();
            }
        } );
    } );
	});
</script>