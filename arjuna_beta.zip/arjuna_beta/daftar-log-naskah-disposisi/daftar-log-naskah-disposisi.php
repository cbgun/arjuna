<?php 
	$judul=ucwords(strtolower(str_replace("-"," ",$getnameurl)));
?>                    
					<div class="card shadow mb-4" style="overflow:auto">
                        <div class="card-header py-3" style="background-color: #f6f0f0;">
                            <h6 class="m-0 font-weight-bold text-primary" style="color:#2C3930!important" ><?=$judul;?></h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive" >
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>NO</th>
                                            <th>NOMOR NASKAH</th>
                                            <th>HAL</th>
                                            <th>KEPADA</th>
                                            <th>INTRUKSI</th>
                                            <th>INTRUKSI TAMBAHAN</th>
                                            <th>LAMPIRAN</th>
                                            <th>TANGGAL DISPOSISI</th>
                                            <th>BATAS WAKTU</th>
                                            <th>AKSI</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr class="border-b border-slate-300">
                                            <td></td>
                                            <td class="max-w-[20rem] py-6 px-2">
                                                    <div class="flex justify-start items-center">
                                                        <div class="MuiInputBase-root MuiInputBase-colorPrimary css-e5c77h">
                                                            <input placeholder="Cari Nomor Naskah" class="MuiInputBase-input css-1bqqmdo rounded-md border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500" 
                                                            type="text" fdprocessedid="i6kfmp">  
                                                        </div>
                                                    </div>
                                            </td>
                                            <td class="max-w-[20rem] py-6 px-2">
                                                    <div class="flex justify-start items-center">
                                                        <div class="MuiInputBase-root MuiInputBase-colorPrimary css-e5c77h">
                                                            <input placeholder="Cari Hal" class="MuiInputBase-input css-1bqqmdo rounded-md border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500" 
                                                            type="text" fdprocessedid="i6kfmp">  
                                                        </div>
                                                    </div>
                                            </td>
                                            <td class="max-w-[20rem] py-6 px-2">
                                                    <div class="flex justify-start items-center">
                                                        <div class="MuiInputBase-root MuiInputBase-colorPrimary css-e5c77h">
                                                            <input placeholder="Cari Kepada" class="MuiInputBase-input css-1bqqmdo rounded-md border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500" 
                                                            type="text" fdprocessedid="i6kfmp">  
                                                        </div>
                                                    </div>
                                            </td>
                                            <td class="max-w-[20rem] py-6 px-2">
                                                    <div class="flex justify-start items-center">
                                                        <div class="MuiInputBase-root MuiInputBase-colorPrimary css-e5c77h">
                                                            <input placeholder="Cari Intruksi" class="MuiInputBase-input css-1bqqmdo rounded-md border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500" 
                                                            type="text" fdprocessedid="i6kfmp">  
                                                        </div>
                                                    </div>
                                            </td>
                                            <td class="max-w-[20rem] py-6 px-2">
                                                    <div class="flex justify-start items-center">
                                                        <div class="MuiInputBase-root MuiInputBase-colorPrimary css-e5c77h">
                                                            <input placeholder="Cari Intruksi Tambahan" class="MuiInputBase-input css-1bqqmdo rounded-md border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500" 
                                                            type="text" fdprocessedid="i6kfmp">  
                                                        </div>
                                                    </div>
                                            </td>
                                            <td></td>
                                            <td></td> 
                                            <td></td>   
                                            <td></td>       
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
