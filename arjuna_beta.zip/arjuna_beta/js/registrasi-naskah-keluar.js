	
	function hapusUploadfile(){
		$('#filelist').html('<div onclick="browseFile(1);" id="idbrowsefile" class="form-control" style="width:100; height:200px" >Untuk menambahkan File, seret dan lepas file tersebut ke sini, atau klik untuk memilih file.</div>');
		$('#filename1').val('');
	}
	function testFilea(e){
		const fileInput = document.getElementById('theFilea');
		if (!fileInput || fileInput.files.length === 0) return;

		const file = fileInput.files[0];
		const filename = file.name;
		const filenamez = file.name.replace(/\s+/g, '');;
		const filenameza = filenamez.replace('.', '');;
		const fileSizeKB = Math.round(file.size / 1024);

		if (fileSizeKB >= 5120) {
			alert("File Terlalu besar, Maksimal 5 MB");
			return;
		}
		
		const fileDisplayHTML = `			
				<div style="border-radius:25px 0 15px 0;width:150px; margin:5px; padding:15px; 
							box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px; position:relative" id="showdocument${filenameza}">
					<div style="position:absolute;right:-5px;top:-10px;line-height:80%; 
								border:1px solid #999;border-radius:100px; width:20px;
								height:20px; text-align:center; cursor:pointer;">
						<i class="fa fa-times" style="font-size:0.8em; color:rgb(239, 2, 125)" onclick="removeFiles(this)" id="${filenameza}"></i>
					</div>
					<div><i class="fa-regular fa-file" style="font-size:3em;"></i></div>
					<div style="font-size:12px;">${filename}</div>
					<div style="font-size:12px;">${fileSizeKB} kb</div>
				</div>`;
		const container = $('#idbrowsefilea');
		if (container.length>0) {
			$('#filelista').html(fileDisplayHTML);
		}else{		
			$('#filelista').append(fileDisplayHTML);
		}			
	}
	
	function testFile(e){		
		const fi = document.getElementById('theFile');
		if (fi.files.length > 0) {
				var filename = e.split('\\')[2];
				
                    const fsize = fi.files.item(0).size;
                    const file = Math.round((fsize / 1024));
					
                    if (file >= 4096) {
                        alert("File Terlalu besar, Maksimal 5 MB");
                    } else {
						$('#filename1').val(filename + '   ' + fsize + ' KB')
							$('#filelist').html('<div id="idbrowsefile" class="form-control" style="width:100; height:200px" ><b>' + filename + '   ' + fsize + '</b> KB <i class="fa fa-times" onclick="hapusUploadfile();" style="color:#ff0000"></i></div>');
                    }					
            }
	}
	
	function changeOpt(e){
		if(e==2){
			$('#visualttea').css('display','none');
		}
		if(e==1){
			$('#visualttea').css('display','block');
		}
	}		
	function browseFilea(e){
		$('#theFilea').trigger('click');
	}		
	
	function browseFile(e){	
		$('#theFile').trigger('click');
	}
	$('.btnmultibrowse').on('click', function() {
		browseFilea();
	});
	function removeFiles(element){
		var currentId = $(element).attr('id');
		$('#showdocument' + currentId).remove();
		var ceksis = $('#filelista').html();
		// alert(ceksis)
		if(ceksis==""){
			$('#filelista').html(`<div onclick="browseFilea(1);" id="idbrowsefilea" name="idbrowsefilea" style="width:100%; height:100%">Untuk menambahkan File, seret dan lepas file tersebut ke sini, atau klik untuk memilih file.</div>`);
		}
	}
