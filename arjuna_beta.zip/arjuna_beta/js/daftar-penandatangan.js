var filepage =window.location.href.split('/');
var linkpage=filepage[4];
var linkweb = '../function/' + linkpage + '.php';

function tambahData(){
	
	$.ajax({
		type: "POST",
		url: linkweb,
		data: {findkey:'showunit'},
		success: function(response){
			var obj = JSON.parse(response);
			var condesc = obj[0].condesc;
			$('.modal-dialog').css('width','80%');
	$('.modal').modal('show');
	$('.modal-header').html('<h5 class="modal-title" id="exampleModalLabel">Tambah</h5>');
	$('.modal-body').html(`
	<table style="width:100%" id="modaltable">
	<tr><td colspan="2">Syarat untuk menambahkan File Tanda Tangan Elektronik yaitu:</td></tr>
	<tr>
		<td valign="top"><i style="background:green;color:#fff; padding:3px; border-radius:15px; font-size:12px;" class="fa fa-check"></i></td>
		<td valign="top">File harus <b>.png</b> dengan ukuran maksimal <b>512 Kb.</b></td>
	</tr>
	<tr>
		<td valign="top"><i style="background:green;color:#fff; padding:3px; border-radius:15px; font-size:12px;" class="fa fa-check"></i></td>
		<td>File tersebut akan digunakan sebagai tanda tangan elektronik, jika File tidak didaftarkan</label> 
	maka tanda tangan menggunakan QR bawaan dari <b>Sistem</td>
	</tr></table>
	<hr>
	<table style="width:100%">
		<tr><td>Penandatanganan <span style="color:#ff0000">*</span></td></tr>
		<tr><td>
			<select class="form-control select2" id="pengguna" style="width:100%">
				${condesc}
			</select>
		</td></tr>
		<tr><td>Status <span style="color:#ff0000">*</span></td></tr>
		<tr><td>
			<input type="radio" id="status1" name="status" value="0">  
			<label for="status1">Aktif</label>
			<input type="radio" id="status2" name="status" value="1">
			<label for="status2">Non Aktif</label>
		</td></tr>
		<tr><td>File </td></tr>
		<tr><td>
		<input type="file" id="fotottd" style="display:none" accept="image/png">
		<img onclick="openUploadttd();" src="../img/No_Image_Available.jpg" style="width:200px; height:150px; border-radius:15px;">
		</td></tr>
	</table>
	`);
			$('.modal-footer').html(`<button class="btn btn-success" type="button" onclick="simpanTtd();"><i class="fa fa-paper-plane"></i> Simpan</button>
                    <button class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Batal</button>`);
	
			$('.select2').select2();
		}
		
	});
	
}

function simpanTtd(){
	var pengguna = $('#pengguna').val();
	var selectedValue = $("input[name='status']:checked").val();
	
	var fileInput = $('#fotottd')[0];
    var file = fileInput.files[0];

    if (!file) {
      alert('Please select an image file.');
      return;
    }
	if (file.type !== 'image/png') {
    $('#fotottdError').text('Only PNG images are allowed.');
    return;
  }
	var maxSize = 524288;
    if (file.size > maxSize) {
      $('#fotottd').text('File is too large. Maximum size is 2MB.');
      return;
    }
	
	var formData = new FormData();
	  formData.append('image', file);
	  formData.append('findkey', 'simpanttd');
	  formData.append('pengguna', pengguna);
	  formData.append('status_', selectedValue);
	
	$.ajax({
		type: "POST",
		url: linkweb,
		data: formData,
		contentType: false,
		processData: false,
		success: function(response){
			var obj = JSON.parse(response);
			var condesc = obj[0].condesc;
			if(condesc==1){
				$('.modal').modal('hide');
				alert('Data berhasil disimpan')
			}
		},
    error: function () {
      alert('Error during upload.');
    }
	});
}
function openUploadttd(){
	$('#fotottd').trigger('click');
}