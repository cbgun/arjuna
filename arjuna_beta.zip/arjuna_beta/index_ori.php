<?php
$actual_link = (empty($_SERVER['HTTPS']) ? 'http' : 'https') . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$urlcount = count(explode('/', $actual_link));
$urlpage = explode('/', $actual_link);
if ($urlcount > 5) {
    $linkurl = '../';
    $getnameurl = $urlpage[4];
} else {
    $linkurl = '';
    $getnameurl = $urlpage[3];
}

?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/x-icon" href="<?= $linkurl; ?>img/favicon.ico">
    <title>Kemenkes RS Sitanala :: ARJUNA</title>

    <!-- Custom fonts for this template-->
    <link href="<?= $linkurl; ?>vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <link href="https://cdn.datatables.net/2.2.2/css/dataTables.dataTables.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/fixedcolumns/5.0.4/css/fixedColumns.dataTables.css" rel="stylesheet">
    <!--<link href="<?= $linkurl; ?>vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">-->
    <!-- Custom styles for this template-->
    <link href="<?= $linkurl; ?>css/sb-admin-2.min.css" rel="stylesheet">
    <style>
        #iconrs {
            color: #ff5bb0;
            font-size: 15px;
        }
    </style>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <?php include "shared/menu_.php"; ?>
        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">
                <?php include "shared/topmenu.php"; ?>

                <!-- Begin Page Content -->
                <div class="container-fluid" style="overflow:scroll">
                    <?php
                    if ($urlcount > 5) {
                        include $getnameurl . "/" . $getnameurl . ".php";
                    } else {
                        include "beranda/beranda.php";
                    }
                    ?>
                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <?php include "shared/footer.php"; ?>

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.html">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!--<script src="https://code.jquery.com/jquery-3.7.1.js"></script>-->

    <!-- Bootstrap core JavaScript-->
    <script src="<?= $linkurl; ?>vendor/jquery/jquery.min.js"></script>
    <script src="<?= $linkurl; ?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript
    <script src="<?= $linkurl; ?>vendor/jquery-easing/jquery.easing.min.js"></script>-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>

    <script src="https://cdn.datatables.net/2.2.2/js/dataTables.js"></script>
    <script src="https://cdn.datatables.net/fixedcolumns/5.0.4/js/dataTables.fixedColumns.js"></script>
    <script src="https://cdn.datatables.net/fixedcolumns/5.0.4/js/fixedColumns.dataTables.js"></script>


    <!--<script src="<?= $linkurl; ?>vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="<?= $linkurl; ?>vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <!--<script src="<?= $linkurl; ?>js/demo/datatables-demo.js"></script>-->

    <!-- Custom scripts for all pages-->
    <script src="<?= $linkurl; ?>js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="<?= $linkurl; ?>vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="<?= $linkurl; ?>js/demo/chart-area-demo.js"></script>
    <script src="<?= $linkurl; ?>js/demo/chart-pie-demo.js"></script>
    <script>
        $("#sidebarToggle, #sidebarToggleTop").on("click", function(e) {
            $(".sidebar").toggleClass("toggled");
            $(".body").toggleClass("sidebar-toggled"); // Or similar, depending on your layout
        });

        // Initially hide the sidebar
        $(document).ready(function() {
            $(".navbar-nav").css("top", '0'); // Make sure the sidebar is initially hidden
        });
    </script>




</body>

</html>