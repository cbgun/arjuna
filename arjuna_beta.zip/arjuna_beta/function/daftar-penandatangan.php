<?php 
include"../config/config_db.php";

	$conPosition='';
$optpengguna='';
	$pesan='';
	// $divisiname=['Divisi Air','Divisi Listrik','Divisi AC','Divisi Bangunan','Divisi Alkes','Divisi Komputer'];
	// $iconbox=['fa-water','fa-bolt-lightning','fa-bath','fa-home','fa-stethoscope','fa-computer'];
	// $iconcolor=['#84cdee','#e10000','#fad747','#c1dd58','#1e3a5f','#ff53a6'];
	// $iconcolorbg=['rgba(132,205,238,0.2)','rgba(225,0,0,0.2)','rgba(250,215,71,0.2)','rgba(193,221,88,0.2)','rgba(30,58,95,0.2)','rgba(255,83,166,0.2)'];
if(isset($_POST['findkey'])){
		if($_POST['findkey']=="simpanttd"){
			$file = $_FILES['image'];

		// Validasi file
		if ($file['type'] !== 'image/png') {
			exit('File harus berupa PNG.');
		}

		if ($file['size'] > 2 * 1024 * 1024) {
			exit('Ukuran file melebihi 2MB.');
		}

		// Upload file
		$targetDir = "../uploads/";
		if (!is_dir($targetDir)) {
			mkdir($targetDir, 0777, true); // buat folder jika belum ada
		}

		$filename = uniqid() . "_" . basename($file["name"]); // agar nama file unik
		$targetFile = $targetDir . $filename;
		if (move_uploaded_file($file["tmp_name"], $targetFile)) {
			// Simpan ke database
			$pengguna = explode('|', $_POST['pengguna']); // ex: "mpin|divisiid"
			$mpin = $pengguna[0];
			$divisiid = $pengguna[1];
			$status = $_POST['status_'];

			$tsqlmenu = "INSERT INTO t_ttd (mpin, gbrttd, divisiid, status_ttd)
						 VALUES (?, ?, ?, ?)";
			$stmt = $dbh->prepare($tsqlmenu);
			$stmt->execute([$mpin, $filename, $divisiid, $status]);

			// echo "Image uploaded and data saved successfully.";
			$status=1;
		} else {
			$status=0;
		}
		$datacontent[]=array('condesc'=>$status);
		echo json_encode($datacontent);
	
	}
	if($_POST['findkey']=="showunit"){
		$tsqlmenu = "SELECT B.nmunit,A.nama,A.karyawanid,A.mpin,A.divisiid from karyawan A 
		LEFT JOIN m_unit B ON B.id=A.divisiid";
		$qmenu = $dbh->query($tsqlmenu);
		$qmenu->execute();
		
		while($row = $qmenu->fetch()){	
			$optpengguna .='<option value="'.$row['mpin'].'|'.$row['divisiid'].'">'.htmlspecialchars($row['nama']).' '.$row['nmunit'].'</option>';
		}
		$datacontent[]=array('condesc'=>$optpengguna);
		echo json_encode($datacontent);
	}
	
}