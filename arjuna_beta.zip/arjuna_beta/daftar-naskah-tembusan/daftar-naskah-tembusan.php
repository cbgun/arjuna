<?php 
	$judul=ucwords(strtolower(str_replace("-"," ",$getnameurl)));
?>                    
					<div class="card shadow mb-4" style="overflow:auto">
                        <div class="card-header py-3" style="background-color: #f6f0f0;">
                            <h6 class="m-0 font-weight-bold text-primary" style="color:#2C3930!important" ><?=$judul;?></h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive" >
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>NO</th>
                                            <th>TANGGAL NASKAH</th>
                                            <th>NOMOR NASKAH</th>
                                            <th>HAL</th>
                                            <th>ASAL NASKAH</th>
                                            <th>STATUS TIDAK LANJUT</th>
                                            <th>STATUS BACA</th>
                                            <th>AKSI</th>
                                        </tr>
                                    </thead>
                                    <tbody></tbody>
                                </table>
                            </div>
                        </div>
                    </div>
