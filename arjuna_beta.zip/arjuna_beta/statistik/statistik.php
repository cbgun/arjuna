
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Dashboard Naskah</title>
  <style>
    body {
      font-family: sans-serif;
      background: #f7f8fa;
      margin: 0;
      padding: 2rem;
    }

    .text-center {
      text-align: center;
    }

    .welcome {
      background: white;
      padding: 2rem;
      border-radius: 15px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.05);
      margin-bottom: 2rem;
    }

    .welcome img {
      width: 55%;
      margin: 1rem 0;
    }

    .btn {
      background-color: #007bff;
      border: none;
      color: white;
      padding: 10px 24px;
      border-radius: 6px;
      cursor: pointer;
      font-size: 1rem;
    }

    .btn:hover {
      background-color: #0056b3;
    }

    .d-flex {
      display: flex;
    }

    .justify-content-end {
      justify-content: flex-end;
    }

    .mt-4 {
      margin-top: 1.5rem;
    }

    .dashboard {
      display: flex;
      flex-direction: column;
      gap: 2rem;
    }

    .section h3 {
      text-align: center;
      color: #6c7a93;
    }

    .card-container {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 1rem;
    }

    .card {
      background: white;
      border-radius: 15px;
      padding: 1rem;
      width: 150px;
      text-align: center;
      box-shadow: 0 4px 10px rgba(0,0,0,0.05);
    }

    .card .icon {
      font-size: 2rem;
      margin-bottom: 0.5rem;
      padding: 10px;
      border-radius: 10px;
      display: inline-block;
    }

    .card .label {
      color: #6c7a93;
      font-weight: 500;
    }

    .card .count {
      font-size: 1.5rem;
      font-weight: bold;
      color: #2c3e50;
    }

    .card.orange .icon { background: #f6a41d; color: white; }
    .card.red .icon { background: #e74c3c; color: white; }
    .card.dark .icon { background: #52627c; color: white; }
  </style>
</head>

<body>

  <!-- Form Sambutan -->
  <div class="welcome">
    <div class="text-center">
      <h2>Hello,<br>Selamat datang di Aplikasi</h2>
      <img src="img/logo_rs.png" alt=" Logo Rumah Sakit">
      <h6>Arsip Rumah Sakit Jaringan Untuk Naskah Administrasi</h6>
    </div>
    <div class="d-flex justify-content-end mt-4" style="gap: 10px;">
      <button type="submit" class="btn">Tampilkan Statistik</button>
    </div>
  </div>

  <!-- Dashboard -->
  <div class="dashboard">
    <!-- Naskah Keluar -->
    <div class="section">
      <h3>Naskah Keluar</h3>
      <div class="card-container">
        <div class="card orange">
          <div class="icon">✈️</div>
          <div class="label">Belum Dikirim</div>
          <div class="count">0</div>
        </div>
        <div class="card red">
          <div class="icon">📪❌</div>
          <div class="label">Ditolak</div>
          <div class="count">0</div>
        </div>
      </div>
    </div>

    <!-- Naskah Masuk -->
    <div class="section">
      <h3>Naskah Masuk</h3>
      <div class="card-container">
        <div class="card orange">
          <div class="icon">📧</div>
          <div class="label">Belum Dibaca</div>
          <div class="count">0</div>
        </div>
        <div class="card dark">
          <div class="icon">↗️</div>
          <div class="label">Belum Ditindaklanjuti</div>
          <div class="count">0</div>
        </div>
      </div>
    </div>

    <!-- TTD Naskah -->
    <div class="section">
      <h3>Tandatangan Naskah</h3>
      <div class="card-container">
        <div class="card red">
          <div class="icon">❌</div>
          <div class="label">Ditolak</div>
          <div class="count">0</div>
        </div>
        <div class="card dark">
          <div class="icon">👤✔️</div>
          <div class="label">Diperbaiki</div>
          <div class="count">0</div>
        </div>
        <div class="card orange">
          <div class="icon">✍️</div>
          <div class="label">Belum Ditandatangani</div>
          <div class="count">0</div>
        </div>
        <div class="card dark">
          <div class="icon">✈️</div>
          <div class="label">Belum Dikirim</div>
          <div class="count">0</div>
        </div>
      </div>
    </div>
  </div>

</body>
</html>