<?php
include "config_db";
$judul = 'Form ' . ucwords(strtolower(str_replace("-", " ", $getnameurl)));

$qpegawai = " SELECT * FROM karyawan ";
$qdata_pegawai = $dbh->query($qpegawai);
$qdata_pegawai->execute();
$option_pegawai = "";
while ($rowqdata_pegawai = $qdata_pegawai->fetch()) {
	$option_pegawai .= '<option value="' . $rowqdata_pegawai['karyawanid'] . '">' . ucwords($rowqdata_pegawai['nama']) . '</option>';
}
?>
<style>
	.myButton {
		box-shadow: inset 0px 1px 0px 0px #fbafe3;
		background: linear-gradient(to bottom, #ff5bb0 5%, #ef027d 100%);
		background-color: #ff5bb0;
		border-radius: 6px;
		border: 1px solid #ee1eb5;
		display: inline-block;
		cursor: pointer;
		color: #ffffff;
		font-family: Arial;
		font-size: 14px;
		font-weight: bold;
		padding: 6px 24px;
		text-decoration: none;
		text-shadow: 0px 1px 0px #c70067;
		text-align: center;
	}

	.myButton:hover {
		background: linear-gradient(to bottom, #ef027d 5%, #ff5bb0 100%);
		background-color: #ef027d;
	}

	.myButton:active {
		position: relative;
		top: 1px;
	}

	.myButtonreset {
		box-shadow: inset 0px 1px 0px 0px #ffffff;
		background: linear-gradient(to bottom, #ededed 5%, #dfdfdf 100%);
		background-color: #ededed;
		border-radius: 6px;
		border: 1px solid #dcdcdc;
		display: inline-block;
		cursor: pointer;
		color: #777777;
		font-family: Arial;
		font-size: 15px;
		font-weight: bold;
		padding: 6px 24px;
		text-decoration: none;
		text-shadow: 0px 1px 0px #ffffff;

	}

	.myButtonreset:hover {
		background: linear-gradient(to bottom, #dfdfdf 5%, #ededed 100%);
		background-color: #dfdfdf;
	}

	.myButtonreset:active {
		position: relative;
		top: 1px;
	}

	#idbrowsefile {
		border: 1px solid rgb(229, 228, 226);
	}

	label {
		font-weight: bold;
		color: #666;
	}

	#idbrowsefile:hover {
		border: 1px dashed #666;
	}

	option {
		font-size: 12px;
	}
</style>
<div class="card shadow mb-4" style="overflow:auto">
	<div class="card-header py-3" style="background-color: #DCE4C9;">
		<h6 class="m-0 font-weight-bold text-primary" style="color:#2C3930!important; font-size:1.3em"><?= $judul; ?></h6>
	</div>
	<div class="card-body">
		<div class="row">
			<div class="col-12">Detail Isi Naskah</div>
			<hr style="border:1px solid rgba(229, 228, 226,0.7); width:100%">
			<div class="col-6">
				<div style="margin-bottom:15px;">
					<label>Dikirimkan melalui <span style="color:#ff0000">*</span></label>
					<select class="form-control select2" id="unitkerja">
						<option> Pilih Unit Kerja</option>
						<?= $option_pegawai; ?>
					</select>
				</div>
				<div style="margin-bottom:15px;">
					<label>Jenis Naskah<span style="color:#ff0000">*</span></label>
					<select class="form-control select2" id="jnsnaskah">
						<option value="0"> Pilih Jenis Naskah</option>
						<option value="1"> NASKAH DINAS</option>
					</select>
				</div>
				<div style="margin-bottom:15px;">
					<label>Sifat Naskah<span style="color:#ff0000">*</span></label>
					<select class="form-control select2">
						<option value="0"> Pilih Sifat Naskah</option>
						<option value="1"> Biasa</option>
						<option value="2"> Terbatas</option>
						<option value="3"> Rahasia</option>
						<option value="4"> Sangat Rahasia</option>
					</select>
				</div>
				<div style="margin-bottom:15px;">
					<label>Klasifikasi<span style="color:#ff0000">*</span></label>
					<select class="form-control select2" id="jnskelasifikasi">
						<option> Pilih Klasifikasi</option>
						<option value="AD">Analisis Determinan Kesehatan</option>
						<option value="AD.01">Analisis Lingkungan Strategis</option>
						<option value="AD.01.01">Analisis Politik Kesehatan</option>
						<option value="AD.01.02">Analisis Sosial Ekonomi </option>
						<option value="AD.01.03">Analisis Perilaku</option>
						<option value="AD.01.04">Analisis Kesehatan Intelegensia</option>
						<option value="AD.02">Pelaksanaan Program</option>
						<option value="AD.02.01">Pelaksanaan Program Analisis Politik Kesehatan</option>
						<option value="AD.02.02">Pelaksanaan Program Analisis Sosial Ekonomi</option>
						<option value="AD.02.03">Pelaksanaan Program Analisis Perilaku</option>
					</select>
				</div>
				<div style="margin-bottom:15px;">
					<label>Nomor Naskah<span style="color:#ff0000">*</span></label>
					<div style=" display:flex;flex:1;flex-direction:row; justify-content:space-between">
						<input class="form-control" style="width:75%;" id="nonaskah" />
						<button class="btn btn-success myButton">Ambil Nomor</button>
					</div>
					<span style="color:#ef027d; font-size:13px;">INFO: Nomor diatas bersifat sementara, guna untuk penyesuaian file digital.</span>
				</div>
				<div style="margin-bottom:15px;">
					<label>Nomor Referensi<span style="color:#ff0000">*</span></label>
					<select class="form-control select2" id="pilihnoref">
						<option> Pilih Nomor Referensi</option>
					</select>
				</div>
			</div>

			<div class="col-6">
				<div style="margin-bottom:15px;">
					<label>Hal<span style="color:#ff0000">*</span></label>
					<textarea class="form-control" cols="5" rows="7" placeholder="Masukkan Hal"></textarea>
				</div>
				<div style="margin-bottom:15px;">
					<label>Isi Ringkas<span style="color:#ff0000">*</span></label>
					<textarea class="form-control" cols="5" rows="7" placeholder="Masukkan Isi Ringkas"></textarea>
				</div>
				<div style="margin-bottom:15px;">
					<label>File naskah<span style="color:#ff0000">*</span></label>
					<input type="file" id="theFile" style="display:none" onchange="testFile(this.value);" />
					<div id="filelist">
						<div onclick="browseFile(1);" id="idbrowsefile" class="form-control" style="width:100; height:200px">Untuk menambahkan File, seret dan lepas file tersebut ke sini, atau klik untuk memilih file.</div>
					</div>
				</div>
				<div style="margin-bottom:15px;">
					<div style=" display:flex;flex:1;flex-direction:row; justify-content:space-between">
						<input class="form-control" style="width:75%;" id="filename1" readonly />
						<input class="form-control" style="width:75%; display:none" id="filename2" />
						<button class="btn btn-success myButton" onclick="browseFile(2);">BROWSE</button>
					</div>
				</div>
				<div style="margin-bottom:15px;">
					<label>Format yang didukung .DOCX dan .PDF (Maksimal 5 Mb)</label>
				</div>
			</div>
			<div class="col-12">LAMPIRAN NASKAH</div>
			<hr style="border:1px solid rgba(229, 228, 226,0.7); width:100%">
			<div class="col-12" style="margin-bottom:15px; font-size:12px;">
				<label>Format yang didukung: .JPG .JPEG .PNG .DOC .DOCX .PDF .XLS .XLSX .PPT .PPTX .MP4 .WAV dan maksimal per file 5 MB
					<br>Mohon memberikan nama file lampiran yang tepat dan benar, tidak menggunakan unsur (titik), (koma), symbol (!@#$%^&* ( ) ) dan total seluruh file maksimal 20 MB</label>
				<div style="margin-bottom:15px; width:100%">
					<label>File naskah<span style="color:#ff0000">*</span></label>
					<input type="file" multiple="multiple" name="theFilea[]" id="theFilea" style="display:block" onchange="testFilea(this.value);" />
					<div id="filelista">
						<div onclick="browseFilea(1);" id="idbrowsefilea" class="form-control" style="width:100; height:200px">
							Untuk menambahkan File, seret dan lepas file tersebut ke sini, atau klik untuk memilih file.
							<div style="display:flex; flex:1; justify-content:center;">
								<div style="border-radius:25px 0 15px 0;width:150px; margin:5px; padding:15px; box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px; position:relative">
									<div style="position:absolute;right:-5px;top:-10px;line-height:80%; border:1px solid #999;border-radius:100px; width:20px;height:20px; text-align:center;"><i class="fa fa-times" style="font-size:0.5em;"></i></div>
									<div><i class="fa-regular fa-file" style="font-size:3em;"></i></div>
									<div style="font-size:12px;">asdasd asd asdasd dasdasd </div>
									<div style="font-size:12px;">15.68 kb</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div style="margin-bottom:15px;">
					<div style=" display:flex;flex:1;flex-direction:row; justify-content:space-between">
						<input class="form-control" style="width:90%;" id="filename1" readonly />
						<input class="form-control" style="width:90%; display:none" id="filename2" value="0 file selected" />
						<button class="btn btn-success myButton" onclick="browseFile(2);">BROWSE</button>
					</div>
				</div>
			</div>
			<br>
			<div class="col-6">
				<label>TUJUAN UTAMA</label>
				<hr>
				<div style="margin-bottom:15px;">
					<label>Grup Tujuan<span style="color:#ff0000">*</span></label>
					<select class="form-control select2">
						<option> Pilih Grup Tujuan</option>
					</select>
				</div>
				<div style="margin-bottom:15px;">
					<label>Utama (Internal / Eksternal Arjuna) <span style="color:#ff0000">*</span></label>
					<select class="form-control select2">
						<option> Pilih Grup Tujuan</option>
					</select>
				</div>
				<div style="margin-bottom:15px;">
					<label>Utama Eksternal Non Arjuna <span style="color:#ff0000">*</span></label>
					<select class="form-control select2">
						<option> Pilih Grup Tujuan</option>
					</select>
				</div>
			</div>
			<div class="col-6">
				<label>TUJUAN TEMBUSAN</label>
				<hr>
				<div style="margin-bottom:15px;">
					<label>Grup Tembusan<span style="color:#ff0000">*</span></label>
					<select class="form-control select2">
						<option> Pilih Grup Tembusan</option>
					</select>
				</div>
				<div style="margin-bottom:15px;">
					<label>Tembusan (Internal / Eksternal Arjuna) <span style="color:#ff0000">*</span></label>
					<select class="form-control select2">
						<option> Pilih Grup Tujuan</option>
					</select>
				</div>
				<div style="margin-bottom:15px;">
					<label>Tembusan Eksternal Non Arjuna <span style="color:#ff0000">*</span></label>
					<select class="form-control select2">
						<option> Pilih Grup Tujuan</option>
					</select>
				</div>
			</div>
			<div class="col-12">
				<label>VERIFIKATOR DAN PENANDATANGAN NASKAH</label>
				<hr>
			</div>
			<div class="col-6">
				<div style="margin-bottom:15px;">
					<label>Verifikator <span style="color:#ff0000">*</span></label>
					<select class="form-control select2">
						<option></option>
					</select>
				</div>
				<div style="margin-bottom:15px;">
					<label>Tipe Tanda Tangan <span style="color:#ff0000">*</span></label>
					<div style="display:flex;flex-direction:row; justify-content:start">
						<div style="margin:5px;"><input type="radio" name="ttd" id="1" value="1" onclick="changeOpt(this.value);"> Elektronik</div>
						<div style="margin:5px;"><input type="radio" name="ttd" id="2" value="2" onclick="changeOpt(this.value);"> Konvensional</div>
					</div>
				</div>
			</div>
			<div class="col-6">
				<div style="margin-bottom:15px;">
					<label>Penandatangan<span style="color:#ff0000">*</span></label>
					<select class="form-control select2">
						<option></option>
					</select>
				</div>
				<div style="margin-bottom:15px;" id="visualttea" style="height:50px;">
					<label>Visual TTE <span style="color:#ff0000">*</span></label>
					<div style="display:flex;flex-direction:row; justify-content:start" id="vtte">
						<div style="margin:5px;"><input type="radio" value="3"> QR Code</div>
						<div style="margin:5px;"><input type="radio" value="4"> Spesimen Gambar</div>
					</div>
				</div>
				<div style="margin-bottom:15px;" id="visualtte">
					<div style="display:flex;flex-direction:row; justify-content:end">
						<button style="margin:5px;" class="btn btn-success myButton" onclick="browseFile(2);"><i class="fa-solid fa-paper-plane"></i> Simpan</button>
						<button style="margin:5px;" class="btn btn-success myButtonreset" onclick="browseFile(2);"><i class="fa-solid fa-repeat"></i> Reset</button>
					</div>

				</div>
			</div>
		</div>
	</div>
</div>
<script>
	function hapusUploadfile() {
		$('#filelist').html('<div onclick="browseFile(1);" id="idbrowsefile" class="form-control" style="width:100; height:200px" >Untuk menambahkan File, seret dan lepas file tersebut ke sini, atau klik untuk memilih file.</div>');
		$('#filename1').val('');
	}

	function testFile(e) {
		// hapusUploadfile();
		const fi = document.getElementById('theFile');

		if (fi.files.length > 0) {
			var filename = e.split('\\')[2];
			// for (const i = 0; i <= fi.files.length - 1; i++) {
			const fsize = fi.files.item(0).size;
			const file = Math.round((fsize / 1024));
			alert(filename)
			if (file >= 4096) {
				alert("File Terlalu besar, Maksimal 5 MB");
			} else {
				var test = $('#filename2').val();
				$('#filename1').val(filename);
				if (test == '1') {
					$('#filelist').html('<div id="idbrowsefile" class="form-control" style="width:100; height:200px" ><b>' + filename + '   ' + fsize + '</b> KB <i class="fa fa-times" onclick="hapusUploadfile();"></i></div>');
				} else if (test == '2') {
					$('#filelist').html('<div id="idbrowsefile" class="form-control" style="width:100; height:200px" ><b>' + filename + '   ' + fsize + '</b> KB <i class="fa fa-users" onclick="hapusUploadfile();"></i></div>');

				}
			}
			// }
		}
	}

	function changeOpt(e) {
		if (e == 2) {
			$('#visualttea').css('display', 'none');
		}
		if (e == 1) {
			$('#visualttea').css('display', 'block');
		}
	}

	function browseFilea(e) {
		// $('#filename2').val(e);
		jQuery('#theFilea').trigger('click');
	}

	function browseFile(e) {
		$('#filename2').val(e);
		jQuery('#theFile').trigger('click');
	}
	// const fi = document.getElementById('file');
</script>