<?php
date_default_timezone_set('Asia/Jakarta');
try {
	  
	  $dbh = new PDO('mysql:host=localhost;dbname=db_surat', "root", "");
	  $dbh->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
	}
	catch (PDOException $e) {
	  print "Koneksi atau query bermasalah1: " . $e->getMessage() . "<br/>";
	  die();
	}
$actual_link = (empty($_SERVER['HTTPS']) ? 'http' : 'https') . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$pageuser=explode('/',$actual_link);
$jumlahll=count($pageuser);
if(count($pageuser)<6){
	$pageuserfix=$pageuser[3];
	$linkrel='';
	$linkcomponent='';
}else{
	$pageuserfix=$pageuser[4];
	$linkrel='../';
	$linkcomponent='../';
}

$getTotday = cal_days_in_month(CAL_GREGORIAN, date('m'), date('Y'));



	?>